package practiceForm;

public class Constant {

    public static final String DEV_ENV = "https://demoqa.com/automation-practice-form";
}
